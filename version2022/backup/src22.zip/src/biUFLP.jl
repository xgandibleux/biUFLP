# ==============================================================================
# fname : biUFLP.jl
# August 2022
# ==============================================================================


# ==============================================================================
function biUFLPsolver(data::Instance)

    # -------------------------------------------------------------------------
    # Information about the instance to solve

    verboseProd ? println("\n    [1] INSTANCE \n") : nothing

    verboseProd ? println("        filename      : $(data.fname)") : nothing
    verboseProd ? println("        nI (users)    : $(data.nI)") : nothing
    verboseProd ? println("        nJ (services) : $(data.nJ)") : nothing


    # -------------------------------------------------------------------------
    # compute a paving of the instance

    verboseProd ? println("\n    [2] PAVING STAGE \n") : nothing

    getTime = time()
    paving = computePavingBranchAndBound(data)
    verboseProd ? println("\n        Time(paving)  : ", round(time()- getTime, digits=4), " sec \n") : nothing

    if verboseProd
        print("        J1 : ")
        for ib in reverse(eachindex(paving))
            print(paving[ib].J1)
        end
        println(" ")
    end

    # -------------------------------------------------------------------------
    # reduce a paving 

    verboseProd ? println("\n    [3] REFINING STAGE \n") : nothing

    getTime = time() 
    reducePaving!(data, paving)
    verboseProd ? println("\n        Time(refining)  : ", round(time()- getTime, digits=4), " sec \n") : nothing

    if verboseProd
        print("        J1 : ")
        for ib in reverse(eachindex(paving))
            print(paving[ib].J1)
        end
        println(" \n")
    end    

end

# ==============================================================================
# fname : main.jl
# August 2022
# ==============================================================================

println("Run biUFLP solver")

include("dataStru.jl")
include("parser.jl")
include("biUFLP.jl")
include("mopRoutines.jl")
include("pavingBB.jl")
include("reducePaving.jl")


# ==============================================================================
# parameters to control the solver

const verboseProd = true   # displays on the terminal the useful info in production
const verboseDev  = false  # displays on the terminal the development info
const graphic     = true   # display on the screen graphics 
const experiment  = true   # run a full numerical experiment


# ==============================================================================
function main()

    # prepare the run for a single resolution or a numerical experiment --------
    if experiment
        # prepare the experiment on a list of instances ------------------------

        #dname = "../data/dataFernandez"
        dname = "../data/dataHarris"

        # get all the names of the datasets for a given collection available in folder 'dnameE'
        fnames = getfnames(dname)

        # run a didactic instance to compile all the code 
        data = load2UFLP("../data/dataDidactic","didactic1.txt")
        biUFLPsolver(data)

    else
        # setup for a single instance -----------------------------------------

        dname = "../data/dataDidactic"
        fnames = ["didactic1.txt"]

        #dname = "../data/dataFernandez"
        #fnames  = ["F50-51.txt"]
    end

    # call the solver ---------------------------------------------------------
    for i in eachindex(fnames)
        verboseProd ? println("\n>>> [0] LOADING DATASET ") : nothing
    
        data  = load2UFLP(dname,fnames[i])
        biUFLPsolver(data) # ajouter le retour avec YN et XE lors integration dans vOptSolver
    end

    print("run completed!")
    return nothing
end

# ==============================================================================
main()
# =============================================================================
# pavingBB.jl
# August 2022
# =============================================================================


# ==============================================================================
"""
    isDominates(yA::Vector{Int64}, yB::Vector{Int64})

    Test if yA stronglyDominates/weaklyDominates/isEqualTo yB
"""
function isDominates(yA::Vector{Int64}, yB::Vector{Int64})

    print("  yA=$yA  yB=$yB ⟶  ")

    if (yA[1] < yB[1]) && (yA[2] < yB[2])
        # strict dominance between yA and yB
        println("yA=$(yA) D yB=$(yB)")
        return true

    elseif ((yA[1] ≤ yB[1]) && (yA[2] < yB[2])) || ((yA[1] < yB[1]) && (yA[2] ≤ yB[2]))
        # weak dominance between yA and yB
        println("yA=$(yA) W yB=$(yB)")
        return true        

    elseif (yA[1] == yB[1]) && (yA[2] == yB[2])
        # egality between yA and yB
        println("yA=$(yA) = yB=$(yB)")  
        return true    

    else
        println("no D|W|= of yA over yB")
        return false
    end
end


# =============================================================================
"""
    computeRunningCost(data::Instance, J1:: Vector{Int64})

    Compute the corresponding running cost of opened services given by J1
"""
function computeRunningCost(data::Instance, J1::Vector{Int64})

    CR=zeros(Int,2)
    for j in J1
        CR[1]+=data.r1[j]
        CR[2]+=data.r2[j]
    end

    return CR
end


# =============================================================================
"""
    evaluateTest1(bU::Box, listBE::Vector{Box})

    apply the test 1 on bU knowing listBE with 
    - bU: an unexpended box
    - listBE: a list of expended boxes 
"""
function evaluateTest1(bU::Box, listBE::Vector{Box})

    print(bU.CR," <-> ")
    for ib in eachindex(listBE)

        println(listBE[ib].y12, " ", listBE[ib].y21)

        # Test if CR ∈ bU is in the cone of one feasible point y12,y21 of b1 ∈ listBE 
        if (isDominates(listBE[ib].y12, bU.CR)) || (isDominates(listBE[ib].y21, bU.CR))
            # found y12 or y21 of a bE who D/W/= CR of bU
            println("  pruning condition by y12 or y21 found => bU (",bU.J1,") pruned !!! \n")
            return true
        end

    end
    println("x")

    return false
end


# =============================================================================
"""
    expand!(data::Instance, b::Box)

    Expand a box in computing its characteristic points y12, y21, yI, yN
"""
function expand!(data::Instance, b::Box)

    # vector of costs corresponding to the lexOptimal allocation
    b.CA12=zeros(Int,2)
    b.CA21=zeros(Int,2)    

    for i in 1:data.nI

        # decide of the allocation for the user i -----------------------------
        vmin12 = typemax(Int64); jmin12 = -1
        vmin21 = typemax(Int64); jmin21 = -1        

        # search the service with minimal cost for user i for f1 and for f2
        for j in b.J1
            if data.c1[i,j]<vmin12
                vmin12 = data.c1[i,j];  jmin12 = j
            end
            if data.c2[i,j]<vmin21
                vmin21 = data.c2[i,j];  jmin21 = j
            end  
        end    
        b.CA12[1]+=data.c1[i,jmin12];  b.CA12[2]+=data.c2[i,jmin12] 
        b.CA21[1]+=data.c1[i,jmin21];  b.CA21[2]+=data.c2[i,jmin21]
    end
     
    b.y12 = b.CR + b.CA12
    b.y21 = b.CR + b.CA21
    b.yI  = Vector{Int64}(undef, 2);   b.yI[1] = b.y12[1];   b.yI[2] = b.y21[2]     
    b.yN  = Vector{Int64}(undef, 2);   b.yN[1] = b.y21[1];   b.yN[2] = b.y12[2]
end


# =============================================================================
function evaluateTest2(bE::Box, listBE::Vector{Box})

    print(bE.yI," <-> ")
    for ib in eachindex(listBE)

        println(listBE[ib].y12, " ", listBE[ib].y21)

        # Test if yI ∈ bE is in the cone of one feasible point y12,y21 of b1 ∈ listBE 
        if (isDominates(listBE[ib].y12, bE.yI)) || (isDominates(listBE[ib].y21, bE.yI))
            # found y12 or y21 of b' ∈ listBE who D/W/= yI of bE
            println("  pruning condition by y12 or y21 found => bE (",bE.J1,") pruned !!! \n")
            return true
        end

    end
    println("x")

    return false    
end


# =============================================================================
function evaluateTest3!(bE::Box, listBE::Vector{Box}, nbPruned::Dict{Symbol, Int64})

    print(bE.y12, " ", bE.y21," <-> ")


    for ib in reverse(2:length(listBE))
        println(listBE[ib].yI)

        # Test if yI of b' ∈ listBE is in the cone of one feasible point y12,y21 of bE 
        if (isDominates(bE.y12, listBE[ib].yI)) || (isDominates(bE.y21, listBE[ib].yI))
            # found y12 or y21 of a bE who D/W/= yI of b' ∈ listBE
            println("  pruning condition by y12 or y21 found => bE (",bE.J1," ",ib,") pruned !!! \n")
            nbPruned[:TEST3]+=1
            deleteat!(listBE,ib)
        end

    end

    return nothing
end


# =============================================================================

"""
    computePavingBranchAndBound(data::Instance)

    compute a paving with the branch-and-bound algorithm following this principle:
    - the tree is implemented by two lists of nodes, 'listL' of unexpended nodes and 'listB' of expended nodes
    - generation of (at most) all subsets of indexes (number of subset = sum_{p=1}^{n} binomial(n,p) )
    - application of test1, test2, test3 to prune useless (unexpended or expended) nodes
"""
function computePavingBranchAndBound(data::Instance)

    # Preliminary definitions and datastructures:
    # - unexpended node: a box defined only by J1,CR
    # - expended node: a box defined by J1,CR,CA12,CA21,yI,yN,y12,y21

    listL = (Box)[]   # list of unexpended nodes
    listB = (Box)[]   # list of expended nodes    

    # vector for counting the number of times that a test has been triggered
    nbPruned = Dict(:TEST1 => 0 , :TEST2 => 0, :TEST3 => 0)


    # Root node of the branch-and-bound ---------------------------------------
    # - each level of the tree is composed of nodes, saved consecutively in a list named 'listL'
    # - each element of 'listL' is composed by a list of indexes corresponding to J1 (opened services)
    # - 'head' indicates the first node for the current level of the tree
    # - 'nexthead' indicates the first node for the next level of the tree
    # - the root of the tree is initialized with J1=∅ (i.e. [])

    # INIT: create the root node which is an unexpended node
    J1    = (Int64)[]
    CR    = [0,0]

    # ENQUEUE: add in the tree the root node 
    push!(listL, Box(J1, CR)) 
    
    # setup the index on the first node for the current level of the tree
    head = 1

    #tester test1 push!(listB, Box(J1, CR)) 
    #tester test1 listB[1].y12=[8000,10000]
    #tester test1 listB[1].y21=[10000,8000]   

    # All others nodes of the branch-and-bound --------------------------------

    # k is an index on the level in the tree
    for k in 1:data.nJ

        nexthead = length(listL)+1   # index on the (future) node serving as head in the next level 

        # DEQUEUE: ------------------------------------------------------------        
        # j is an index on the node from listL to be processed at the current level of the tree 
        for j in head:length(listL)

            # TEST 1 ----------------------------------------------------------
            # test if CR is weakly dominated

            test1 = false

            print(j," test 1: ")
            if head == 1
                # test1 is not triggered (root node has no predecessor)
                println("-")
            else
                test1 = evaluateTest1(listL[j],listB)
            end

            if test1

                # the child nodes are NOT generated                
                nbPruned[:TEST1]+=1

            else
                # the child nodes are generated

                # get the last index in J1 of the father node
                if length(listL[j].J1)==0
                    # the father is the root (no index)
                    lastIndex = 0
                else
                    # the father is a node with a set of indexes; keep the last index
                    lastIndex = listL[j].J1[end]
                end  

                # generate the children nodes and place them in the next level of the tree  
                for i in lastIndex+1:data.nJ

                    # create an unexpended node
                    J1 = deepcopy(listL[j].J1)
                    push!(J1,i)
                    CR = computeRunningCost(data,J1)

                    # ENQUEUE: add in the tree the current node 
                    push!(listL, Box(J1, CR))

                end

                # -------------------------------------------------------------
                # EXPAND: 
                if head == 1
                    # expand is not triggered (root node cannot be expanded)
                    println("-")
                else
                    # bU becomes bE
                    b = deepcopy(listL[j])
                    expand!(data::Instance, b::Box)

                    print(j," test 2: ")
                    # TEST 2 --------------------------------------------------
                    # test if b is weakly dominated
                    test2 = evaluateTest2(b,listB)
                    
                    if test2

                        # the expanded nodes is killed                
                        nbPruned[:TEST2]+=1
                    
                    else
                        # ENQUEUE: add in the tree ('listB') the current expended node 'b'
                        pushfirst!(listB, b)

                        print(j," test 3: ")
                        # TEST 3 ----------------------------------------------
                        # test if b' ∈ listB is weakly dominated by b
                        evaluateTest3!(b,listB,nbPruned) 
        
                    end

                end
                
            end


        end

        # update the index for the next level
        head = nexthead
    end

    # summary of the activity -------------------------------------------------  
    println("\n        #test 1 activated : ", nbPruned[:TEST1])
    println("        #test 2 activated : ", nbPruned[:TEST2])  
    println("        #test 3 activated : ", nbPruned[:TEST3])     
   
    println("\n        #max of boxes           : ", 2^data.nJ-1)
    println("        #active boxes           : ", length(listB))
    println("        #unexpended boxes       : ", length(listL))       
    println("        ratio of boxes pruned   : ", round((1.0-length(listB)/length(listL))*100; digits=2)  , "%") 
 
    return listB
end
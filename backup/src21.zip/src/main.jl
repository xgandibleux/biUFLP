# ==============================================================================
# fname : main.jl
# August 2022
# ==============================================================================

include("dataStru.jl")
include("parser.jl")
include("pavingBB.jl")


# ==============================================================================
# parameters to control the displays on the terminal and granphics

const verbose = true
const graphic = true


# ==============================================================================
# Load an instance of 2UFLP

dname = "../data/dataDidactic"
#dname  = "../data/dataFernandez"
fname = "didactic1.txt"
#fname  = "F53-54.txt"

verbose ? println("\n\n>>> [1] LOADING STAGE \n") : nothing

data  = load2UFLP(dname,fname)

verbose ? println("        instance      : $fname") : nothing
verbose ? println("        nI (users)    : $(data.nI)") : nothing
verbose ? println("        nJ (services) : $(data.nJ)") : nothing

# ==============================================================================
# compute an exhaustive paving of the instance

verbose ? println("\n\n>>> [2] PAVING STAGE \n") : nothing

getTime = time()
paving = computePavingBranchAndBound(data)
println("\n        Time(paving)  : ", round(time()- getTime, digits=4), " sec \n\n")

for ib in reverse(eachindex(paving))
    println(paving[ib].J1)
end
